# Firmware Deployment Guide

## CORS Resolution for GitHub Pages

### Problem
GitHub Releases asset URLs do not include CORS headers, preventing browser-based applications from downloading firmware binaries directly. This blocks the Web Serial API from accessing firmware files.

### Solution
Firmware binaries are now served from the GitHub Pages site (`/public/firmware/`) which automatically includes proper CORS headers.

### Deployment Process

1. **Add Firmware Files**
   - Place `.bin` files in `/public/firmware/` directory
   - Files are automatically served via GitHub Pages at: `https://sense360store.github.io/sense360-flash/firmware/`

2. **Update GitHub Releases**
   - Continue publishing releases with firmware assets for metadata
   - The app will use GitHub API to get release information but download from CORS-enabled URLs

3. **Automatic URL Mapping**
   - The app automatically maps GitHub release assets to CORS-enabled URLs
   - Example: `sense360_v2.v2.0.0.factory.bin` → `https://sense360store.github.io/sense360-flash/firmware/sense360_v2.v2.0.0.factory.bin`

### File Structure
```
public/
├── firmware/
│   ├── sense360_v2.v2.0.0.factory.bin
│   ├── air_quality_monitor.v1.0.0.stable.bin
│   └── co2_monitor.v1.0.0.beta.bin
└── 404.html
```

### Testing
- All firmware downloads now use CORS-enabled URLs
- Enhanced error handling for CORS-related issues
- Graceful fallback messaging for network errors

### Benefits
- ✅ No CORS blocking in production
- ✅ Reliable firmware downloads across all browsers
- ✅ Maintains GitHub Releases workflow for metadata
- ✅ Static file serving via GitHub Pages CDN